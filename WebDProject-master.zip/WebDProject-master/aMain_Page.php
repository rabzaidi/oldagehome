<html>
<head>
	<title>Registration Page </title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body background="bgg.jpg" >
	<div class="header" >
		<img src="sunshine.jpg" alt="logo"/>
	<h1>Sunshine Welfare Trust</h1>
	</div>
	<ul>
  <li><a href="firstregister.php">Home</a></li>
  <li><a href="oldhome.php">Register</a></li>
  <li><a href="login.php">Sign in</a></li>
  <li><a href="sponsers.html">Sponsers</a></li>
  <li><a href='http://www.oldagehomeindia.in/gallerypicture.html' >Gallery</a></li>
  <li style="float:right"><a class="active" href="aboutus.html">About</a></li>
   </ul>
</br>
</br>
</br>
   <right>
  <b>Rescue & Admission</b>
  <img  src='icon-1.png' align="left">
  <p >Our rescue team moves around Delhi/NCR and brings the elders lying on streets in extremely dying condition and then admit them. Delhi Police, Government Hospitals and NGO’s also helps the abandoned elders to get admitted in our Ashram.</p>
</right>
</br>
</br>
<left>
  <b>
  	<img  src='icon-2.png' align="left">
Health Checkup & SOS Treatment
</b>
<p>Then we provide the immediate relief by performing first-aid treatment and Complete Health checkup including Blood test and Full body checkup</p>
</left>
</br>
</br>
<right>
<b>
	<img  src='icon-3.png' align="left">
Medical Treatment & Care
</b>
<p>We provide required treatment and medication to the elderly by a team of qualified doctors. 24*7 trained nursing staff and Medical team is available.</p>
</right>
</br>
</br>
<left>
<b>
	<img  src='icon-6.png' align="left">

Cremation
</b>
<p>
	We do cremation according to the religion in case of demise.
</p>
</left>
</br>
</br>
 
</body>
</html>